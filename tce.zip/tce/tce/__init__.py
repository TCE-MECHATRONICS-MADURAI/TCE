# Version of the application.
__version__ = '1.0.3'
